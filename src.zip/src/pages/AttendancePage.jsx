// src/pages/AttendancePage.jsx
import React, { useState, useEffect } from 'react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import FormField from '../components/ui/FormField';
import Table from '../components/ui/Table';
import { Tabs, Tab } from '../components/ui/Tabs';
import AttendanceCalendar from '../components/shared/AttendanceCalendar';
import { fetchAttendance, fetchStudentsForAttendance } from '../services/attendanceService';
import '../styles/pages/attendance.css';

const AttendancePage = () => {
  const [attendance, setAttendance] = useState([]);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentDate, setCurrentDate] = useState(new Date().toISOString().split('T')[0]);
  const [activeTab, setActiveTab] = useState('all');
  const [toast, setToast] = useState({ show: false, message: '' });

  useEffect(() => {
    loadAttendance();
    loadStudents();
  }, [currentDate]);

  const loadAttendance = async () => {
    try {
      setLoading(true);
      const data = await fetchAttendance(currentDate);
      setAttendance(data);
      setError(null);
    } catch (err) {
      setError('فشل تحميل بيانات الحضور. يرجى المحاولة لاحقًا.');
      console.error('Error fetching attendance:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadStudents = async () => {
    try {
      const data = await fetchStudentsForAttendance();
      setStudents(data);
    } catch (err) {
      console.error('Error fetching students for attendance:', err);
    }
  };

  const handleDateChange = (date) => {
    setCurrentDate(date);
  };

  const filterAttendance = () => {
    if (activeTab === 'all') {
      return attendance;
    } else if (activeTab === 'present') {
      return attendance.filter(a => a.status === 'حاضر');
    } else if (activeTab === 'absent') {
      return attendance.filter(a => a.status === 'غائب');
    }
    return attendance;
  };

  const showToast = (message) => {
    setToast({ show: true, message });
    setTimeout(() => {
      setToast({ show: false, message: '' });
    }, 3000);
  };

  const handleDelete = async (id) => {
    if (window.confirm('هل أنت متأكد من حذف هذه الدفعة؟')) {
      try {
        // هنا يجب أن يكون لديك دالة deleteAttendance في خدمة الحضور
        // await deleteAttendance(id);
        loadAttendance();
        showToast('تم حذف الدفعة بنجاح!');
      } catch (error) {
        console.error('Error deleting fee:', error);
        showToast('فشل حذف الدفعة.');
      }
    }
  };

  const columns = [
    { header: 'الاسم', accessor: 'name' },
    { header: 'الصف', accessor: 'grade' },
    { header: 'الشعبة', accessor: 'section' },
    { 
      header: 'الحالة', 
      accessor: 'status',
      render: (attendance) => (
        <span className={`status ${attendance.status === 'حاضر' ? 'status-present' : 'status-absent'}`}>
          {attendance.status}
        </span>
      )
    },
    { header: 'الوقت', accessor: 'time' },
    { header: 'الملاحظات', accessor: 'notes' },
    { header: 'الإجراءات', accessor: 'actions' }
  ];

  const renderActions = (attendance) => (
    <div className="actions">
      <Button 
        variant="primary" 
        size="sm" 
        icon="fas fa-edit"
        title="تعديل"
      />
      <Button 
        variant="danger" 
        size="sm" 
        icon="fas fa-trash"
        title="حذف"
        onClick={() => handleDelete(attendance.id)}
      />
    </div>
  );

  if (error) {
    return (
      <div className="error-message">
        <i className="fas fa-exclamation-circle"></i> {error}
      </div>
    );
  }

  return (
    <div className="attendance-page">
      <h1 className="page-title">
        <i className="fas fa-calendar-check"></i>
        الحضور والغياب
      </h1>

      <Card>
        <div className="card-header">
          <h2 className="card-title">
            <i className="fas fa-calendar-day"></i>
            تسجيل الحضور ليوم {new Date(currentDate).toLocaleDateString('ar-EG')}
          </h2>
        </div>
        <div className="form-row" style={{ marginBottom: '20px' }}>
          <div className="form-group" style={{ maxWidth: '300px' }}>
            <label className="form-label">اختر التاريخ</label>
            <FormField
              name="attendanceDate"
              type="date"
              value={currentDate}
              onChange={(e) => handleDateChange(e.target.value)}
            />
          </div>
        </div>
        
        <Tabs>
          <Tab label="جميع الطلاب" onClick={() => setActiveTab('all')}>
            <Table 
              columns={columns} 
              data={filterAttendance()} 
              renderActions={renderActions} 
              emptyMessage="لا توجد بيانات حضور لهذا اليوم"
            />
          </Tab>
          <Tab label="الحاضر" onClick={() => setActiveTab('present')}>
            <Table 
              columns={columns} 
              data={filterAttendance()} 
              renderActions={renderActions} 
              emptyMessage="لا توجد بيانات حضور لهذا اليوم"
            />
          </Tab>
          <Tab label="الغائب" onClick={() => setActiveTab('absent')}>
            <Table 
              columns={columns} 
              data={filterAttendance()} 
              renderActions={renderActions} 
              emptyMessage="لا توجد بيانات غياب لهذا اليوم"
            />
          </Tab>
        </Tabs>
      </Card>

      <Card>
        <div className="card-header">
          <h2 className="card-title">
            <i className="fas fa-calendar-alt"></i>
            تقويم الحضور
          </h2>
        </div>
        <AttendanceCalendar 
          attendanceData={attendance}
          onDateSelect={setCurrentDate}
        />
      </Card>

      {/* إضافة Toast للإشعارات */}
      <div className={`toast ${toast.show ? 'show' : ''}`}>
        {toast.message}
      </div>
    </div>
  );
};

export default AttendancePage;