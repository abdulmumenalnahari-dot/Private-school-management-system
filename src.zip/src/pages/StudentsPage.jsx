// src/pages/StudentsPage.jsx
import React, { useState, useEffect } from 'react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import FormField from '../components/ui/FormField';
import Table from '../components/ui/Table';
import { fetchStudents, addStudent, deleteStudent, fetchSections } from '../services/studentService';

const StudentsPage = () => {
  const [students, setStudents] = useState([]);
  const [sections, setSections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    idNumber: '',
    grade: '',
    section: '',
    phone: '',
    email: '',
    address: '',
    dob: '',
    notes: ''
  });
  const [toast, setToast] = useState({ show: false, message: '', type: 'success' });

  useEffect(() => {
    loadStudents();
    loadSections();
  }, []);

  const loadStudents = async () => {
    try {
      setLoading(true);
      const data = await fetchStudents();
      setStudents(data);
      setError(null);
    } catch (err) {
      setError('فشل تحميل بيانات الطلاب. يرجى المحاولة لاحقًا.');
      console.error('Error fetching students:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadSections = async () => {
    try {
      const data = await fetchSections();
      setSections(data);
    } catch (err) {
      console.error('Error fetching sections:', err);
      showToast('فشل تحميل الشُعب. تأكد من تشغيل السيرفر.', 'error');
    }
  };

  const showToast = (message, type = 'success') => {
    setToast({ show: true, message, type });
    setTimeout(() => {
      setToast({ show: false, message: '', type: 'success' });
    }, 3000);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      // تقسيم الاسم الكامل إلى اسم أول واسم عائلة
      const [first_name, ...last_name_parts] = formData.name.split(' ');
      const last_name = last_name_parts.join(' ') || first_name;
      
      // تحويل تاريخ الميلاد إلى التنسيق الصحيح (YYYY-MM-DD)
      let birth_date = null;
      if (formData.dob) {
        const dateObj = new Date(formData.dob);
        if (!isNaN(dateObj)) {
          birth_date = dateObj.toISOString().split('T')[0];
        }
      }
      
      // الحصول على section_id الصحيح من قائمة الشُعب
      let section_id = null;
      if (formData.section) {
        const selectedSection = sections
          .flatMap(cls => cls.sections)
          .find(sec => sec.name === formData.section);
          
        if (selectedSection) {
          section_id = selectedSection.id;
        } else {
          throw new Error('الشعبة المحددة غير موجودة');
        }
      }
      
      // تحديد العام الدراسي الحالي
      const academic_year_id = 1; // يجب أن يكون هذا القيمة الفعلية من قاعدة البيانات
      
      const studentData = {
        first_name,
        last_name,
        gender: 'ذكر', // يمكنك إضافة حقل جنس في النموذج لاحقًا
        birth_date,
        nationality: 'يمني',
        religion: 'إسلام',
        address: formData.address,
        parent_phone: formData.phone,
        parent_email: formData.email,
        parent_guardian_name: 'ولي الأمر', // يمكنك إضافة حقل لاسم ولي الأمر لاحقًا
        parent_guardian_relation: 'أب', // يمكنك إضافة حقل لعلاقة ولي الأمر لاحقًا
        admission_date: new Date().toISOString().split('T')[0],
        section_id,
        academic_year_id
      };

      await addStudent(studentData);
      setFormData({
        name: '',
        idNumber: '',
        grade: '',
        section: '',
        phone: '',
        email: '',
        address: '',
        dob: '',
        notes: ''
      });
      loadStudents();
      showToast('تم إضافة الطالب بنجاح!');
    } catch (error) {
      console.error('Error adding student:', error);
      showToast(`فشل إضافة الطالب: ${error.message || 'يرجى التحقق من البيانات'}`, 'error');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('هل أنت متأكد من حذف هذا الطالب؟')) {
      try {
        await deleteStudent(id);
        loadStudents();
        showToast('تم حذف الطالب بنجاح!');
      } catch (error) {
        console.error('Error deleting student:', error);
        showToast('فشل حذف الطالب.', 'error');
      }
    }
  };

  const columns = [
    { header: 'الاسم', accessor: 'name' },
    { header: 'الهوية', accessor: 'idNumber' },
    { header: 'الصف', accessor: 'grade' },
    { header: 'الشعبة', accessor: 'section' },
    { header: 'الجوال', accessor: 'phone' },
    { header: 'الإجراءات', accessor: 'actions' }
  ];

  const renderActions = (student) => (
    <div className="actions">
      <Button 
        variant="primary" 
        size="sm" 
        icon="fas fa-edit"
        title="تعديل"
      />
      <Button 
        variant="danger" 
        size="sm" 
        icon="fas fa-trash"
        title="حذف"
        onClick={() => handleDelete(student.id)}
      />
    </div>
  );

  if (error) {
    return (
      <div className="error-message">
        <i className="fas fa-exclamation-circle"></i> {error}
      </div>
    );
  }

  return (
    <div className="students-page">
      <h1 className="page-title">
        <i className="fas fa-users"></i>
        إدارة الطلاب
      </h1>

      <Card>
        <div className="card-header">
          <h2 className="card-title">
            <i className="fas fa-user-plus"></i>
            إضافة طالب جديد
          </h2>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="form-row">
            <FormField
              label="الاسم الكامل"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              required
              placeholder="الاسم الأول والاسم العائلي"
            />
            <FormField
              label="رقم الهوية/الإقامة"
              name="idNumber"
              value={formData.idNumber}
              onChange={handleInputChange}
              required
              placeholder="مثلاً: STD123456"
            />
          </div>
          <div className="form-row">
            <FormField
              label="الصف الدراسي"
              name="grade"
              type="select"
              value={formData.grade}
              onChange={handleInputChange}
              options={[
                { value: '', label: 'اختر الصف' },
                { value: 'الصف الأول الابتدائي', label: 'الصف الأول الابتدائي' },
                { value: 'الصف الثاني الابتدائي', label: 'الصف الثاني الابتدائي' },
                { value: 'الصف الثالث الابتدائي', label: 'الصف الثالث الابتدائي' },
                { value: 'الصف الرابع الابتدائي', label: 'الصف الرابع الابتدائي' },
                { value: 'الصف الخامس الابتدائي', label: 'الصف الخامس الابتدائي' },
                { value: 'الصف السادس الابتدائي', label: 'الصف السادس الابتدائي' },
                { value: 'الصف الأول المتوسط', label: 'الصف الأول المتوسط' },
                { value: 'الصف الثاني المتوسط', label: 'الصف الثاني المتوسط' },
                { value: 'الصف الثالث المتوسط', label: 'الصف الثالث المتوسط' }
              ]}
              required
            />
            <FormField
              label="الشعبة"
              name="section"
              type="select"
              value={formData.section}
              onChange={handleInputChange}
              options={[
                { value: '', label: 'اختر الشعبة' },
                ...sections.flatMap(cls => 
                  cls.sections.map(sec => ({
                    value: sec.name,
                    label: sec.name
                  }))
                )
              ]}
              required
            />
          </div>
          <div className="form-row">
            <FormField
              label="رقم جوال ولي الأمر"
              name="phone"
              type="tel"
              value={formData.phone}
              onChange={handleInputChange}
              required
              placeholder="مثلاً: 712345678"
            />
            <FormField
              label="البريد الإلكتروني"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleInputChange}
              placeholder="مثلاً: example@example.com"
            />
          </div>
          <div className="form-row">
            <FormField
              label="العنوان"
              name="address"
              value={formData.address}
              onChange={handleInputChange}
              placeholder="مثلاً: صنعاء، الحي السياسي"
            />
            <FormField
              label="تاريخ الميلاد"
              name="dob"
              type="date"
              value={formData.dob}
              onChange={handleInputChange}
            />
          </div>
          <div className="form-row">
            <FormField
              label="ملاحظات"
              name="notes"
              type="textarea"
              value={formData.notes}
              onChange={handleInputChange}
              rows="3"
              placeholder="ملاحظات إضافية عن الطالب"
            />
          </div>
          <Button type="submit" variant="primary">
            <i className="fas fa-save"></i>
            حفظ المعلومات
          </Button>
        </form>
      </Card>

      <Card>
        <div className="card-header">
          <h2 className="card-title">
            <i className="fas fa-users"></i>
            قائمة الطلاب
          </h2>
        </div>
        {loading ? (
          <div className="loading">
            <i className="fas fa-spinner fa-spin"></i> جاري التحميل...
          </div>
        ) : students.length === 0 ? (
          <div className="no-data">لا يوجد طلاب مسجلين</div>
        ) : (
          <Table 
            columns={columns} 
            data={students} 
            renderActions={renderActions} 
          />
        )}
      </Card>
    </div>
  );
};

export default StudentsPage;