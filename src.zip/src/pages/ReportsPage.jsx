// src/pages/ReportsPage.jsx
import React, { useState, useEffect } from 'react';
import Card from '../components/ui/Card';
import FormField from '../components/ui/FormField';
import StudentProfile from '../components/shared/StudentProfile';
import AttendanceCalendar from '../components/shared/AttendanceCalendar';
import Table from '../components/ui/Table';
import { fetchStudentsForReport, fetchStudentReport } from '../services/reportService';

const ReportsPage = () => {
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [reportData, setReportData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadStudents();
  }, []);

  const loadStudents = async () => {
    try {
      const data = await fetchStudentsForReport();
      setStudents(data);
    } catch (err) {
      console.error('Error fetching students for report:', err);
    }
  };

  const handleStudentChange = async (e) => {
    const studentId = e.target.value;
    if (!studentId) {
      setSelectedStudent(null);
      setReportData(null);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      const student = students.find(s => s.id === studentId);
      setSelectedStudent(student);
      
      const report = await fetchStudentReport(studentId);
      setReportData(report);
    } catch (err) {
      setError('فشل تحميل تقرير الطالب. يرجى المحاولة لاحقًا.');
      console.error('Error fetching student report:', err);
    } finally {
      setLoading(false);
    }
  };

  const renderAttendanceStatus = (status) => {
    if (!status) return null;
    
    return (
      <span className={`status ${status === 'حاضر' ? 'status-present' : 'status-absent'}`}>
        {status}
      </span>
    );
  };

  const feeColumns = [
    { header: 'التاريخ', accessor: 'date' },
    { header: 'النوع', accessor: 'type' },
    { header: 'المبلغ', accessor: 'amount' },
    { header: 'طريقة الدفع', accessor: 'method' },
    { 
      header: 'الحالة', 
      accessor: 'status',
      render: () => (
        <span className="status status-paid">مسدد</span>
      )
    }
  ];

  return (
    <div className="reports-page">
      <h1 className="page-title">
        <i className="fas fa-file-alt"></i>
        التقارير
      </h1>

      <Card>
        <div className="card-header">
          <h2 className="card-title">
            <i className="fas fa-user-graduate"></i>
            تقرير الطالب
          </h2>
        </div>
        <div className="form-row" style={{ marginBottom: '20px' }}>
          <div className="form-group" style={{ maxWidth: '300px' }}>
            <label className="form-label">اختر الطالب</label>
            <FormField
              name="reportStudent"
              type="select"
              onChange={handleStudentChange}
              options={[
                { value: '', label: 'اختر طالبًا' },
                ...students.map(student => ({
                  value: student.id,
                  label: student.name
                }))
              ]}
            />
          </div>
        </div>

        {error && (
          <div className="error-message">
            <i className="fas fa-exclamation-circle"></i> {error}
          </div>
        )}

        {loading ? (
          <div className="loading">
            <i className="fas fa-spinner fa-spin"></i> جاري تحميل التقرير...
          </div>
        ) : selectedStudent && reportData ? (
          <div id="studentReport">
            <StudentProfile student={selectedStudent} />
            
            <div className="info-grid" style={{ margin: '30px 0' }}>
              <div className="info-item">
                <div className="info-label">نسبة الحضور</div>
                <div className="info-value" style={{ fontSize: '1.8rem' }}>
                  {reportData.attendanceRate}%
                </div>
              </div>
              <div className="info-item">
                <div className="info-label">الحالة المالية</div>
                <div className="info-value" style={{ fontSize: '1.8rem' }}>
                  {reportData.financialStatus}
                </div>
              </div>
              <div className="info-item">
                <div className="info-label">الرسوم المتبقية</div>
                <div 
                  className="info-value" 
                  style={{ 
                    fontSize: '1.8rem', 
                    color: reportData.pendingFees > 0 ? 'var(--danger)' : 'var(--success)' 
                  }}
                >
                  {reportData.pendingFees.toLocaleString()} ر.س
                </div>
              </div>
            </div>

            <Card>
              <div className="card-header">
                <h2 className="card-title">
                  <i className="fas fa-calendar-check"></i>
                  سجل الحضور لهذا الشهر
                </h2>
              </div>
              <AttendanceCalendar 
                attendanceData={reportData.attendance}
              />
            </Card>

            <Card style={{ marginTop: '25px' }}>
              <div className="card-header">
                <h2 className="card-title">
                  <i className="fas fa-money-bill-wave"></i>
                  السجل المالي
                </h2>
              </div>
              <Table 
                columns={feeColumns} 
                data={reportData.fees} 
                emptyMessage="لا توجد دفعات مسجلة"
              />
            </Card>
          </div>
        ) : selectedStudent ? (
          <div className="no-report-message">
            <i className="fas fa-info-circle"></i> لا توجد بيانات كافية لتقرير هذا الطالب
          </div>
        ) : (
          <div className="select-student-message">
            <i className="fas fa-user-graduate"></i> يرجى اختيار طالب لعرض التقرير
          </div>
        )}
      </Card>
    </div>
  );
};

export default ReportsPage;