// src/services/attendanceService.js
import api from './api';

export const fetchAttendance = async (date) => {
  try {
    const response = await api.get(`/attendance?date=${date}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching attendance:', error);
    throw error;
  }
};

export const fetchStudentsForAttendance = async () => {
  try {
    const response = await api.get('/students/for-attendance');
    return response.data;
  } catch (error) {
    console.error('Error fetching students for attendance:', error);
    throw error;
  }
};