const API_BASE_URL = "http://172.16.2.174:3000";

export default API_BASE_URL;
